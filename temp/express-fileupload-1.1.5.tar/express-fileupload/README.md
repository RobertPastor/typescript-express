# Installation
> `npm install --save @types/express-fileupload`

# Summary
This package contains type definitions for express-fileupload (https://github.com/richardgirges/express-fileupload#readme).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/express-fileupload.

### Additional Details
 * Last updated: Thu, 10 Sep 2020 17:17:09 GMT
 * Dependencies: [@types/express](https://npmjs.com/package/@types/express)
 * Global values: none

# Credits
These definitions were written by [Gintautas Miselis](https://github.com/Naktibalda), [Sefa Ilkimen](https://github.com/silkimen), [Tomas Vosicky](https://github.com/vosatom), and [Piotr Błażejewicz](https://github.com/peterblazejewicz).
